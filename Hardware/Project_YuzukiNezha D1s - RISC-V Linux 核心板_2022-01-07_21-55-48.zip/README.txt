<p>经历了期末考试挂科风险、板子刚寄到学校我就回家了、疫情元器件停止派送等一些列人情世故后，它终于来了：YuzukiNezha D1s</p>
<p> </p>
<p><img src="//image.lceda.cn/pullimage/JqYzp4KqNtQrpMgksXfaokfDFA0kVpssdSb7LdLI.jpeg" alt="JqYzp4KqNtQrpMgksXfaokfDFA0kVpssdSb7LdLI.jpeg" /></p>
<p> </p>
<h2>特点</h2>
<ul><li>Mini PCIE版型，引出接口，可以自由搭配以太网，RGB屏、MIPI屏底板。不需要排线连接转接。</li>
<li>板载电源树、USB接口、TP排线接口、SPI与TF卡槽。PG11引出一颗LED，没有底板也能愉快点灯。</li>
<li>四层板设计、工艺不需要加钱（最好花钱沉个金）、0402优雅阻容。</li>
<li>板载WiFi模块,可以焊接各种适配模块。</li>
<li>LCEDA格式，OSHWHUB与Github开源。协议CERN-OHL-P</li>
</ul><p> </p>
<h2>来点图</h2>
<h3>正面图</h3>
<p><img src="//image.lceda.cn/pullimage/xFbqdQN64ututfg0KYBcWOivlAHzAnRyJ1jUzxpQ.jpeg" alt="xFbqdQN64ututfg0KYBcWOivlAHzAnRyJ1jUzxpQ.jpeg" /></p>
<h3>背面图</h3>
<p><img src="//image.lceda.cn/pullimage/uIiQoEEEhDfeICNPsxqNzJssN1ryluvmeEHyIIGH.jpeg" alt="uIiQoEEEhDfeICNPsxqNzJssN1ryluvmeEHyIIGH.jpeg" /></p>
<h3>三兄弟</h3>
<p><img src="//image.lceda.cn/pullimage/cF6E9ncwtNq3UdeczfYk8pz2rsT0cCaOAeBmDHyP.jpeg" alt="cF6E9ncwtNq3UdeczfYk8pz2rsT0cCaOAeBmDHyP.jpeg" /></p>
<p> </p>
<h2>目前问题（杀鸽</h2>
<div>TF卡槽买错了还没有验证</div>
<div>Audio部分被砍了（主要是期末考试没时间画了</div>
<div>WiFi 模块的配置电阻还没给，只能用特定型号的模块</div>
<div>没时间画丝印（（（</div>
<div>AWOL LOGO 反了（（（</div>
<div> </div>
<div>
<h2>验证xfel</h2>
<p> </p>
<p><img src="https://bbs.aw-ol.com/assets/uploads/files/1641483031644-6a408930-f33d-463f-afa2-b6c283efe9a1-img_3282.jpg" alt="1641483031644-6a408930-f33d-463f-afa2-b6c283efe9a1-img_3282.jpg" /></p>
<p> </p>
<h2>关于TF卡槽</h2>
<p>以为一模一样<br /><a href="https://bbs.aw-ol.com/assets/uploads/files/1641483183078-b1a5b38f-eeca-4360-8b94-b8f4292edc1d-image.png" target="_blank" rel="noreferrer noopener"><img src="https://bbs.aw-ol.com/assets/uploads/files/1641483183078-b1a5b38f-eeca-4360-8b94-b8f4292edc1d-image.png" alt="b1a5b38f-eeca-4360-8b94-b8f4292edc1d-image.png" width="1200" height="753" /></a><br />然后背刺<br /><a href="https://bbs.aw-ol.com/assets/uploads/files/1641483137347-cee8ee3c-9704-4d7a-ab6b-511c1a8a0707-_b-m8-tn-uxq-z-8p-96-11t.png" target="_blank" rel="noreferrer noopener"><img src="https://bbs.aw-ol.com/assets/uploads/files/1641483137347-cee8ee3c-9704-4d7a-ab6b-511c1a8a0707-_b-m8-tn-uxq-z-8p-96-11t.png" alt="" width="1200" height="613" /></a></p>
</div>            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。